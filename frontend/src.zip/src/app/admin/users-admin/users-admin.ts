import { Component } from '@angular/core';

@Component({
  selector: 'app-users-admin',
  imports: [],
  templateUrl: './users-admin.html',
  styleUrl: './users-admin.css'
})
export class UsersAdmin {

}
