export const environment = {
  production: true,
  apiUrl: 'https://your-domain.com/api' // 👈 domain thật khi deploy
};
