package com.thubongshop.backend.payment;

public enum PaymentStatus {
    pending,
    paid,
    failed
}
