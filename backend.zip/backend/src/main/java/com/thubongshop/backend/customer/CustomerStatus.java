package com.thubongshop.backend.customer;

public enum CustomerStatus {
    ACTIVE, INACTIVE, BANNED
}
