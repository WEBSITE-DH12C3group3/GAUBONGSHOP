package com.thubongshop.backend.customer;


public enum CustomerTier {
DONG, BAC, VANG, BACHKIM, KIMCUONG
}