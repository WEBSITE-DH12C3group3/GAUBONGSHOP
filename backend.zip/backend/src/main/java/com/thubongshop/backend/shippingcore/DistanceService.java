package com.thubongshop.backend.shippingcore;

import org.springframework.stereotype.Service;

@Service("shippingCoreDistanceService")
public class DistanceService {

  public double haversineKm(double lat1, double lon1, double lat2, double lon2){
    final double R = 6371d;
    double dLat = Math.toRadians(lat2 - lat1);
    double dLon = Math.toRadians(lon2 - lon1);
    double a = Math.sin(dLat/2)*Math.sin(dLat/2)
        + Math.cos(Math.toRadians(lat1))*Math.cos(Math.toRadians(lat2))
        * Math.sin(dLon/2)*Math.sin(dLon/2);
    double c = 2*Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return Math.round(R*c*100.0)/100.0;
  }
}
