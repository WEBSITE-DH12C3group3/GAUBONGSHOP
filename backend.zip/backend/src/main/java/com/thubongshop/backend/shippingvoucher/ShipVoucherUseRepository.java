package com.thubongshop.backend.shippingvoucher;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ShipVoucherUseRepository extends JpaRepository<ShipVoucherUse, ShipVoucherUse.ShipVoucherUseId> {
}
