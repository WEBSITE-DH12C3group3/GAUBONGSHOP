package com.thubongshop.backend.review;

public interface ReviewStats {
    Double getAvgRating();
    Long getTotalReviews();
}
