package com.thubongshop.backend.payment;

public enum PaymentMethod {
    COD,
    BANK_TRANSFER,
    E_WALLET,
    CREDIT_CARD
}


