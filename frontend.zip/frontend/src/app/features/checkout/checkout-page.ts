import { Component, ChangeDetectionStrategy, ChangeDetectorRef, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, Validators, FormGroup } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { finalize } from 'rxjs/operators';

import { AddressMapPickerComponent } from '../../shared/components/address-map-picker.component';
import { AddressSuggestInputComponent } from '../../shared/components/address-suggest-input.component';
import { AddressBookSelectComponent } from '../../shared/components/address-book-select.component';

import { CartService } from '../../shared/services/cart.service';
import { ShopInfoService } from '../../shared/services/shop-info.service';
import { VietnamLocationService, Province, District, Ward } from '../../shared/services/vietnam-location.service';

import {
  ShippingPublicService,
  ShippingQuoteRequest,
  PreviewShippingResponse,
} from '../../shared/services/shipping-public.service';

import { OrderClientService } from '../../shared/services/order-client.service';

import { GeoService, AddressComponents, SuggestItem } from '../../shared/services/geo.service';
import { AddressBookService, UserAddress } from '../../shared/services/address-book.service';

type CartItem = {
  productId: number;
  quantity: number;
  price: number;
  weightKgPerItem?: number | null;
  name?: string;
};

@Component({
  selector: 'app-checkout-page',
  standalone: true,
  imports: [
    CommonModule, ReactiveFormsModule, FormsModule, RouterModule,
    AddressMapPickerComponent, AddressSuggestInputComponent, AddressBookSelectComponent,
  ],
  templateUrl: './checkout-page.html',
  styleUrls: ['./checkout-page.css'],
  changeDetection: ChangeDetectionStrategy.Default,
})
export class CheckoutPageComponent implements OnInit {
  // -------- Cart ----------
  cart?: {
    items: CartItem[];
    totalQuantity: number;
    totalAmount: number;
    selectedItems: CartItem[];
    selectedAmount: number;
  };

  // -------- Shop origin (hiển thị/ước tính) ----------
  origin?: { lat: number; lng: number; address?: string };

  // -------- Modal bản đồ ----------
  showMap = false;

  // -------- Forms ----------
  addressForm!: FormGroup;
  shippingForm!: FormGroup;
  paymentForm!: FormGroup;
  noteForm!: FormGroup;

  // -------- VN locations ----------
  provinces: Province[] = [];
  districts: District[] = [];
  wards: Ward[] = [];
  loadingProv = false;
  loadingDist = false;
  loadingWard = false;

  // -------- Preview shipping ----------
  loadingPreview = false;
  preview?: PreviewShippingResponse | null;
  errMsg?: string;

  // -------- Derived ----------
  subtotal = 0;
  weightKg = 0;

  // -------- UI flags ----------
  placing = false;

  constructor(
    private fb: FormBuilder,
    private cdr: ChangeDetectorRef,
    private router: Router,
    private cartSvc: CartService,
    private shipSvc: ShippingPublicService,
    private orderSvc: OrderClientService,
    private vnLoc: VietnamLocationService,
    private geo: GeoService,
    private addrBook: AddressBookService,
    private shopInfo: ShopInfoService
  ) {}

  ngOnInit(): void {
    // Địa chỉ + toạ độ giao hàng
    this.addressForm = this.fb.group({
      receiverName: ['', [Validators.required, Validators.maxLength(120)]],
      phone: ['', [Validators.required, Validators.pattern(/^0\d{9,10}$/)]],
      provinceCode: ['', Validators.required],
      districtCode: ['', Validators.required],
      wardCode: ['', Validators.required],
      addressLine: ['', [Validators.required, Validators.maxLength(255)]],
      lat: [null, Validators.required],
      lng: [null, Validators.required],
    });

    // Shipping (mã freeship)
    this.shippingForm = this.fb.group({
      voucherCode: [''],
    });

    // Payment & note (để template không lỗi)
    this.paymentForm = this.fb.group({ method: ['COD', Validators.required] });
    this.noteForm = this.fb.group({ note: [''] });

    // Origin
    this.shopInfo.getOrigin().subscribe(o => { this.origin = o; this.cdr.detectChanges(); });

    // Cart
    this.loadCart();

    // VN locations
    this.loadProvinces();
    this.addressForm.get('provinceCode')!.valueChanges.subscribe((code: string) => {
      this.addressForm.patchValue({ districtCode: '', wardCode: '' }, { emitEvent: false });
      this.wards = [];
      if (code) this.loadDistricts(code);
    });
    this.addressForm.get('districtCode')!.valueChanges.subscribe((code: string) => {
      this.addressForm.patchValue({ wardCode: '' }, { emitEvent: false });
      if (code) this.loadWards(code);
    });

    // Auto preview khi form thay đổi
    this.addressForm.valueChanges.subscribe(() => this.tryPreview());
    this.shippingForm.valueChanges.subscribe(() => this.tryPreview());
  }

  // ---------------- Cart ----------------
  private loadCart(): void {
    const snap = (this.cartSvc as any).getSnapshot?.();
    if (snap) this.applyCartSummary(snap);
    this.cartSvc.getSummary().subscribe((summary: any) => this.applyCartSummary(summary));
  }

  private applyCartSummary(resp: any) {
    const items: CartItem[] = (resp.selectedItems ?? resp.items ?? []) as CartItem[];
    const amount = (resp.selectedAmount ?? resp.totalAmount ?? 0) as number;

    this.cart = {
      items: resp.items ?? [],
      totalQuantity: resp.totalQuantity ?? 0,
      totalAmount: resp.totalAmount ?? 0,
      selectedItems: items,
      selectedAmount: amount,
    };

    this.subtotal = items.reduce((s, it) => s + (it.price ?? 0) * (it.quantity ?? 0), 0);
    this.weightKg = items.reduce((s, it) => s + (it.weightKgPerItem ?? 0) * (it.quantity ?? 0), 0);
    if (this.weightKg <= 0) {
      const qty = items.reduce((s, it) => s + (it.quantity ?? 0), 0);
      this.weightKg = Math.max(0, qty * 0.2);
    }
    this.tryPreview();
    this.cdr.detectChanges();
  }

  // ---------------- Map & gợi ý ----------------
  openMapPicker() { this.showMap = true; this.cdr.detectChanges(); }
  onMapCancel() { this.showMap = false; this.cdr.detectChanges(); }

  onMapPicked(e: { lat: number; lng: number; address?: string }) {
    this.showMap = false;
    this.addressForm.patchValue({ lat: e.lat, lng: e.lng }, { emitEvent: true });

    this.geo.reverse(e.lat, e.lng).subscribe({
      next: (a: AddressComponents) => {
        const provCode = this.codeByName(this.provinces, a.province);
        if (provCode) {
          this.addressForm.patchValue({ provinceCode: provCode, districtCode: '', wardCode: '' }, { emitEvent: false });
          this.loadDistricts(provCode);
          setTimeout(() => {
            const distCode = this.codeByName(this.districts, a.district);
            if (distCode) {
              this.addressForm.patchValue({ districtCode: distCode, wardCode: '' }, { emitEvent: false });
              this.loadWards(distCode);
              setTimeout(() => {
                const wardCode = this.codeByName(this.wards, a.ward);
                if (wardCode) this.addressForm.patchValue({ wardCode }, { emitEvent: false });
              }, 200);
            }
            this.addressForm.patchValue({ addressLine: a.street || a.fullAddress || e.address || '' }, { emitEvent: false });
            this.tryPreview();
          }, 200);
        } else {
          this.addressForm.patchValue({ addressLine: a.street || a.fullAddress || e.address || '' }, { emitEvent: false });
          this.tryPreview();
        }
        this.cdr.detectChanges();
      },
      error: () => { this.tryPreview(); }
    });
  }

  onSuggestPicked(it: SuggestItem) {
    if (it.lat != null && it.lng != null) {
      this.addressForm.patchValue({ lat: it.lat, lng: it.lng }, { emitEvent: false });
    }
    const pCode = this.codeByName(this.provinces, it.province);
    if (pCode) {
      this.addressForm.patchValue({ provinceCode: pCode, districtCode: '', wardCode: '' }, { emitEvent: false });
      this.loadDistricts(pCode);
      setTimeout(() => {
        const dCode = this.codeByName(this.districts, it.district);
        if (dCode) {
          this.addressForm.patchValue({ districtCode: dCode, wardCode: '' }, { emitEvent: false });
          this.loadWards(dCode);
          setTimeout(() => {
            const wCode = this.codeByName(this.wards, it.ward);
            if (wCode) this.addressForm.patchValue({ wardCode: wCode }, { emitEvent: false });
            this.addressForm.patchValue({ addressLine: it.street || it.fullAddress }, { emitEvent: false });
            this.tryPreview();
          }, 200);
        } else {
          this.addressForm.patchValue({ addressLine: it.street || it.fullAddress }, { emitEvent: false });
          this.tryPreview();
        }
      }, 200);
    } else {
      this.addressForm.patchValue({ addressLine: it.street || it.fullAddress }, { emitEvent: false });
      this.tryPreview();
    }
    this.cdr.detectChanges();
  }

  saveAddress() {
    const f = this.addressForm.value;
    const payload: UserAddress = {
      receiverName: f.receiverName,
      phone: f.phone,
      provinceCode: f.provinceCode,
      districtCode: f.districtCode,
      wardCode: f.wardCode,
      addressLine: f.addressLine,
      latitude: f.lat ?? undefined,
      longitude: f.lng ?? undefined,
      isDefault: false,
    };
    this.addrBook.create(payload).subscribe();
  }

  onChooseAddress(a: UserAddress) {
    this.addressForm.patchValue({
      receiverName: a.receiverName,
      phone: a.phone,
      provinceCode: a.provinceCode,
      districtCode: a.districtCode,
      wardCode: a.wardCode,
      addressLine: a.addressLine,
      lat: a.latitude ?? null,
      lng: a.longitude ?? null,
    }, { emitEvent: true });
    this.tryPreview();
  }

  // ---------------- VN locations ----------------
  loadProvinces() {
    this.loadingProv = true;
    this.vnLoc.getProvinces()
      .pipe(finalize(() => { this.loadingProv = false; this.cdr.detectChanges(); }))
      .subscribe(list => { this.provinces = list ?? []; this.cdr.detectChanges(); });
  }

  loadDistricts(provinceCode: string) {
    this.loadingDist = true;
    this.districts = []; this.wards = [];
    (this.vnLoc as any).getDistricts(provinceCode)
      .pipe(finalize(() => { this.loadingDist = false; this.cdr.detectChanges(); }))
      .subscribe((list: District[]) => { this.districts = list ?? []; this.cdr.detectChanges(); });
  }

  loadWards(districtCode: string) {
    this.loadingWard = true;
    this.wards = [];
    (this.vnLoc as any).getWards(districtCode)
      .pipe(finalize(() => { this.loadingWard = false; this.cdr.detectChanges(); }))
      .subscribe((list: Ward[]) => { this.wards = list ?? []; this.cdr.detectChanges(); });
  }

  // ---------------- Preview shipping (1 kết quả) ----------------
  private canPreview(): boolean {
    const f = this.addressForm.value;
    return !!(this.subtotal >= 0 && this.weightKg >= 0 && f.lat != null && f.lng != null);
  }

  tryPreview() {
    if (!this.cart || !this.canPreview()) return;

    const f = this.addressForm.value;
    const req: ShippingQuoteRequest = {
      orderSubtotal: this.subtotal,
      weightKg: this.weightKg,
      destLat: f.lat,
      destLng: f.lng,
      voucherCode: (this.shippingForm.value.voucherCode || '').trim() || undefined,
      carrierCode: undefined,
      serviceCode: undefined,
    };

    this.loadingPreview = true;
    this.errMsg = undefined;
    this.preview = null;

    this.shipSvc.previewShipping(req)
      .pipe(finalize(() => { this.loadingPreview = false; this.cdr.detectChanges(); }))
      .subscribe({
        next: (res: PreviewShippingResponse) => { this.preview = res; this.cdr.detectChanges(); },
        error: (err) => { this.preview = null; this.errMsg = err?.error?.error || 'Không tính được phí vận chuyển'; this.cdr.detectChanges(); },
      });
  }

  // ---------------- Tổng tiền ----------------
  itemsAmount(): number { return this.subtotal; }
  shippingFee(): number { return this.preview?.finalFee ?? 0; }
  totalToPay(): number { return this.itemsAmount() + this.shippingFee(); }

  // để template dùng check
  isAddressValid(): boolean { return this.addressForm.valid; }

  // ---------------- Đặt hàng ----------------
  placeOrder() {
    if (!this.cart || !this.preview) { this.errMsg = 'Vui lòng chọn vị trí và tính phí vận chuyển.'; return; }
    if (this.addressForm.invalid) { this.addressForm.markAllAsTouched(); return; }

    const f = this.addressForm.value;
    const items = (this.cart.selectedItems || []).map(it => ({
      productId: it.productId,
      quantity: it.quantity,
      weightKgPerItem: it.weightKgPerItem ?? 0.2,
    }));

    const body = {
      receiverName: f.receiverName,
      phone: f.phone,
      addressLine: `${f.addressLine}`,
      province: this.provinceName,
      destLat: f.lat,
      destLng: f.lng,
      voucherCode: (this.shippingForm.value.voucherCode || '').trim() || undefined,
      items
    };

    this.placing = true; this.errMsg = undefined; this.cdr.detectChanges();
    this.orderSvc.create(body as any)
      .pipe(finalize(() => { this.placing = false; this.cdr.detectChanges(); }))
      .subscribe({
        next: (res: any) => this.router.navigate(['/order-success'], { queryParams: { id: res?.id } }),
        error: (err) => { this.errMsg = err?.error?.error || 'Đặt hàng thất bại'; console.error(err); },
      });
  }

  // ---------------- Utils ----------------
  private vnNormalize(s: string): string {
    return (s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '')
      .replace(/đ/g, 'd').replace(/Đ/g, 'D').toLowerCase().trim();
  }
  private codeByName<T extends { name: string; code: string | number }>(list: T[], name?: string): string | null {
    const key = this.vnNormalize(name || '');
    const hit = (list || []).find(x => {
      const n = this.vnNormalize(x.name);
      return n === key || n.includes(key) || key.includes(n);
    });
    return hit ? String(hit.code) : null;
  }

  get provinceName(): string {
    const code = String(this.addressForm?.value?.provinceCode ?? '');
    const p = (this.provinces || []).find(x => String(x.code) === code);
    return p?.name || '';
  }
  get districtName(): string {
    const code = String(this.addressForm?.value?.districtCode ?? '');
    const d = (this.districts || []).find(x => String(x.code) === code);
    return d?.name || '';
  }
}
