export interface ShippingCarrier {
  id?: number;
  code: string;
  name: string;
  active: boolean;
  createdAt?: string;
}
