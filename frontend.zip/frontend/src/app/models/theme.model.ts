export interface Theme {
  id: number;
  name: string;
  slug: string;
  description?: string;
  categories: { id: number; name: string; slug: string }[];
  categoryCount: number;
}

export interface ThemeReq {
  name: string;
  slug?: string;
  description?: string;
  categoryIds: number[];
}
