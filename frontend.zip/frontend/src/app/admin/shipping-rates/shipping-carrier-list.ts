import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { ShippingCarrierAdminService } from '../../shared/services/shipping-carrier-admin.service';
import { ShippingCarrier } from '../../models/shipping-carrier.model';

@Component({
  selector: 'app-shipping-carrier-list',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './shipping-carrier-list.html'
})
export class ShippingCarrierListComponent implements OnInit {
  rows: ShippingCarrier[] = [];
  page = 0; size = 10; total = 0;
  q = ''; active: 'all'|'true'|'false' = 'all';
  sort = 'code,asc'; loading=false;

  constructor(private api: ShippingCarrierAdminService) {}
  ngOnInit(){ this.load(); }

  load(){
    this.loading = true;
    const act = this.active === 'all' ? undefined : this.active === 'true';
    this.api.list(this.page, this.size, this.sort, this.q, act).subscribe(res=>{
      this.rows = res.content; this.total = res.totalElements; this.loading=false;
    }, _=> this.loading=false);
  }
  onToggle(row:ShippingCarrier){
    this.api.toggle(row.id!).subscribe(r=>{
      row.active = r.active;
    });
  }
  onDelete(id:number){
    if (!confirm('Xoá carrier này?')) return;
    this.api.delete(id).subscribe(()=> this.load());
  }
}
