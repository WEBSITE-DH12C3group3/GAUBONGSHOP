import { Component, Input, OnChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { CarrierRateRule } from '../../models/carrier-rate-rule.model';
import { CarrierRateRuleAdminService } from '../../shared/services/carrier-rate-rule-admin.service';

@Component({ 
    standalone: true,
    imports: [CommonModule, FormsModule, RouterModule],
    selector:'app-carrier-rate-rule-list', templateUrl:'./carrier-rate-rule-list.html' })
export class CarrierRateRuleListComponent implements OnChanges {
  @Input() serviceId!: number;
  rows: CarrierRateRule[] = [];
  constructor(private api: CarrierRateRuleAdminService) {}
  ngOnChanges(){ if (this.serviceId) this.api.byService(this.serviceId).subscribe(r => this.rows = r); }
}
