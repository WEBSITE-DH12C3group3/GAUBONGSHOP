import { Component, Input, OnChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { ShippingService } from '../../models/shipping-service.model';
import { ShippingServiceAdminService } from '../../shared/services/shipping-service-admin.service';

@Component({ 
    selector:'app-shipping-service-list', 
    standalone: true,
    imports: [CommonModule, FormsModule, RouterModule],
    templateUrl:'./shipping-service-list.html' })
export class ShippingServiceListComponent implements OnChanges {
  @Input() carrierId!: number;
  rows: ShippingService[] = [];
  constructor(private api: ShippingServiceAdminService) {}
  ngOnChanges(){ if (this.carrierId) this.api.byCarrier(this.carrierId).subscribe(r => this.rows = r); }
}
