import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { ShippingCarrierAdminService } from '../../shared/services/shipping-carrier-admin.service';

@Component({
  selector: 'app-shipping-carrier-form',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './shipping-carrier-form.html'
})
export class ShippingCarrierFormComponent implements OnInit {
  id?: number;
  form!: FormGroup;          // chỉ khai báo
  saving = false;

  constructor(
    private fb: FormBuilder,
    private api: ShippingCarrierAdminService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit() {
    this.form = this.fb.group({
      code: ['', [Validators.required, Validators.maxLength(50)]],
      name: ['', [Validators.required, Validators.maxLength(120)]],
      active: [true]
    });

    const idParam = this.route.snapshot.paramMap.get('id');
    this.id = idParam ? +idParam : undefined;

    if (this.id) {
      this.api.get(this.id).subscribe(v => this.form.patchValue(v));
    }
  }

  submit() {
    if (this.form.invalid) return;
    this.saving = true;
    const payload = this.form.value as any;
    const obs = this.id ? this.api.update(this.id!, payload) : this.api.create(payload);
    obs.subscribe({
      next: () => { this.saving = false; this.router.navigateByUrl('/admin/shipping-rates'); },
      error: () => { this.saving = false; }
    });
  }
}
