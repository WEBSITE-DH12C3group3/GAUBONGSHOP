import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ShippingCarrierListComponent } from './shipping-carrier-list';
import { ShippingCarrierFormComponent } from './shipping-carrier-form';
import { ShippingServiceListComponent } from './shipping-service-list';
import { CarrierRateRuleListComponent } from './carrier-rate-rule-list';

const routes: Routes = [
  { path: '', component: ShippingCarrierListComponent, data: { permission: 'manage_shippingrate' } },
  { path: 'carriers/new', component: ShippingCarrierFormComponent, data: { permission: 'manage_shippingrate' } },
  { path: 'carriers/:id', component: ShippingCarrierFormComponent, data: { permission: 'manage_shippingrate' } },

  // tuỳ bạn mở màn tạo/sửa riêng cho Service/Rule sau
  { path: 'services', component: ShippingCarrierListComponent }, // giữ bậc điều hướng từ list carrier
  { path: 'services/:carrierId', component: ShippingServiceListComponent },
  { path: 'rules/:serviceId', component: CarrierRateRuleListComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ShippingRatesRoutingModule {}
