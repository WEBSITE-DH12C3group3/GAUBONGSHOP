import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { environment } from '../../../environments/environment';
import { Coupon, CouponResponse } from '../../models/coupon.model';

@Injectable({ providedIn: 'root' })
export class CouponAdminService {
  private readonly apiUrl = `${environment.apiUrl}/admin/coupons`;
  constructor(private http: HttpClient) {}

  private norm = (v: any): Coupon => ({
    id: v.id,
    code: v.code,
    description: v.description ?? '',
    discountType: v.discountType,
    discountValue: +v.discountValue,
    maxDiscountAmount: v.maxDiscountAmount != null ? +v.maxDiscountAmount : null,
    minOrderAmount: v.minOrderAmount != null ? +v.minOrderAmount : null,
    excludeDiscountedItems: !!v.excludeDiscountedItems,
    applicablePaymentMethods: v.applicablePaymentMethods ?? null,
    applicableRoles: v.applicableRoles ?? null,
    regionInclude: v.regionInclude ?? null,
    regionExclude: v.regionExclude ?? null,
    firstOrderOnly: !!v.firstOrderOnly,
    stackable: !!v.stackable,
    maxUses: v.maxUses != null ? +v.maxUses : null,
    usedCount: v.usedCount != null ? +v.usedCount : 0,
    maxUsesPerUser: v.maxUsesPerUser != null ? +v.maxUsesPerUser : null,
    startDate: v.startDate ?? null,
    endDate: v.endDate ?? null,
    active: !!v.active,
    createdAt: v.createdAt,
    updatedAt: v.updatedAt,
    categoryIds: v.categoryIds ?? [],
    brandIds: v.brandIds ?? [],
    productIds: v.productIds ?? []
  });

  private normList = (raw: any): CouponResponse => ({
    items: (raw?.items ?? []).map(this.norm),
    page: raw?.page ?? 0,
    size: raw?.size ?? 10,
    totalPages: raw?.totalPages ?? 1,
    total: raw?.totalElements
  });

  list(q = '', page = 0, size = 10, sort = 'id,desc'): Observable<CouponResponse> {
    let params = new HttpParams().set('page', page).set('size', size).set('sort', sort);
    if (q) params = params.set('q', q);
    return this.http.get<any>(this.apiUrl, { params }).pipe(map(this.normList));
  }

  get(id: number): Observable<Coupon> {
    return this.http.get<any>(`${this.apiUrl}/${id}`).pipe(map(r => this.norm(r?.coupon ?? r)));
  }

  create(payload: any): Observable<Coupon> {
    return this.http.post<any>(this.apiUrl, payload).pipe(map(r => this.norm(r?.coupon ?? r)));
  }

  update(id: number, payload: any): Observable<Coupon> {
    return this.http.put<any>(`${this.apiUrl}/${id}`, payload).pipe(map(r => this.norm(r?.coupon ?? r)));
  }

  delete(id: number) {
    return this.http.delete(`${this.apiUrl}/${id}`);
  }

  setActive(id: number, value: boolean) {
    return this.http.patch<any>(`${this.apiUrl}/${id}/active`, null, { params: { value } })
      .pipe(map(r => this.norm(r?.coupon ?? r)));
  }
}
