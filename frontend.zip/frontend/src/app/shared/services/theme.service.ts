import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { Observable } from 'rxjs';
import { Theme, ThemeReq } from '../../models/theme.model';

@Injectable({ providedIn: 'root' })
export class ThemeService {
  private http = inject(HttpClient);
  private base = environment.apiUrl;

  // public
  getAll(): Observable<Theme[]> {
    return this.http.get<Theme[]>(`${this.base}/themes`);
  }
  getBySlug(slug: string): Observable<Theme> {
    return this.http.get<Theme>(`${this.base}/themes/${slug}`);
  }

  // admin
  adminList(): Observable<Theme[]> {
    return this.http.get<Theme[]>(`${this.base}/admin/themes`);
  }
  create(req: ThemeReq): Observable<Theme> {
    return this.http.post<Theme>(`${this.base}/admin/themes`, req);
  }
  update(id: number, req: ThemeReq): Observable<Theme> {
    return this.http.put<Theme>(`${this.base}/admin/themes/${id}`, req);
  }
  delete(id: number): Observable<void> {
    return this.http.delete<void>(`${this.base}/admin/themes/${id}`);
  }
}
