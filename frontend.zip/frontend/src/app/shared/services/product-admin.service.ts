import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { Observable, catchError } from 'rxjs'; // 👈 sửa import: bỏ of, switchMap; thêm catchError

@Injectable({ providedIn: 'root' })
export class ProductAdminService {
  private readonly apiUrl = `${environment.apiUrl}/admin/products`;

  constructor(private http: HttpClient) {}

  listPaged(
    keyword?: string,
    categoryId?: number,
    brandId?: number,
    page: number = 0,
    size: number = 10,
    minPrice?: number | null,
    maxPrice?: number | null
  ): Observable<any> {
    let params = new HttpParams().set('page', page).set('size', size);
    if (keyword)  params = params.set('keyword', keyword);
    if (categoryId !== undefined && categoryId !== null) params = params.set('categoryId', categoryId);
    if (brandId    !== undefined && brandId    !== null) params = params.set('brandId',    brandId);
    if (minPrice   !== undefined && minPrice   !== null) params = params.set('minPrice',   minPrice);
    if (maxPrice   !== undefined && maxPrice   !== null) params = params.set('maxPrice',   maxPrice);

    return this.http.get<any>(this.apiUrl, { params });
  }

  getDetail(id: number): Observable<any> { return this.http.get<any>(`${this.apiUrl}/${id}`); }
  create(product: any): Observable<any> { return this.http.post<any>(this.apiUrl, product); }
  update(id: number, product: any): Observable<any> { return this.http.put<any>(`${this.apiUrl}/${id}`, product); }
  delete(id: number): Observable<any> { return this.http.delete(`${this.apiUrl}/${id}`); }

  createFull(body: any): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/full`, body);
  }

  // ✅ dùng catchError để fallback sang PUT thường nếu /full chưa có
  updateFull(id: number, body: any): Observable<any> {
    return this.http.put<any>(`${this.apiUrl}/${id}/full`, body).pipe(
      catchError(() => this.http.put<any>(`${this.apiUrl}/${id}`, body))
    );
  }
 getAllProducts(page: number = 0, size: number = 10): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}?page=${page}&size=${size}`);
  }
  // Gợi ý: trả any để dễ normalize nhiều kiểu payload
  getAttributes(): Observable<any> {
    return this.http.get<any>(`${environment.apiUrl}/attributes`);
  }
}
