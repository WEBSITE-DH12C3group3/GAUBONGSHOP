import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { Observable } from 'rxjs';
import { ShippingService } from '../../models/shipping-service.model';

@Injectable({ providedIn: 'root' })
export class ShippingServiceAdminService {
  private base = `${environment.apiUrl}/admin/shipping/services`;
  constructor(private http: HttpClient) {}

  byCarrier(carrierId:number): Observable<ShippingService[]> {
    return this.http.get<ShippingService[]>(`${this.base}/by-carrier/${carrierId}`);
  }
  get(id:number){ return this.http.get<ShippingService>(`${this.base}/${id}`); }
  create(payload: ShippingService){ return this.http.post<ShippingService>(this.base, payload); }
  update(id:number, payload: ShippingService){ return this.http.put<ShippingService>(`${this.base}/${id}`, payload); }
  toggle(id:number){ return this.http.patch<ShippingService>(`${this.base}/${id}/toggle`, {}); }
  delete(id:number){ return this.http.delete<void>(`${this.base}/${id}`); }
}
