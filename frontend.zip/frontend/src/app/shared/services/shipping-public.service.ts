import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

export interface ShippingQuoteRequest {
  orderSubtotal: number;
  weightKg: number;
  destLat: number;
  destLng: number;
  voucherCode?: string | null;
  carrierCode?: string | null;
  serviceCode?: string | null;
}

export interface ShippingQuote {
  carrier: string;
  service: string;
  distanceKm: number;
  feeBeforeVoucher: number;
  feeAfterVoucher: number;
  etaDaysMin: number | null;
  etaDaysMax: number | null;
}

export interface PreviewShippingResponse {
  carrier: string;
  service: string;
  distanceKm: number;
  feeBeforeDiscount: number;
  discount: number;
  finalFee: number;
  etaDaysMin: number | null;
  etaDaysMax: number | null;
}

export interface CreateOrderItem {
  productId: number;
  quantity: number;
  weightKgPerItem?: number | null;
}

export interface CreateOrderRequest {
  receiverName: string;
  phone: string;
  addressLine: string;
  province: string;
  destLat: number;
  destLng: number;
  voucherCode?: string | null;
  items: CreateOrderItem[];
}

@Injectable({ providedIn: 'root' })
export class ShippingPublicService {
  private readonly API = '/api';

  constructor(private http: HttpClient) {}

  // Public quote (không cần auth)
  quote(req: ShippingQuoteRequest): Observable<ShippingQuote> {
    return this.http.post<ShippingQuote>(`${this.API}/public/shipping/quotes`, req);
  }

  // Preview trong luồng checkout (cần auth vì URL nằm trong /api/client)
  previewShipping(req: ShippingQuoteRequest): Observable<PreviewShippingResponse> {
    return this.http.post<PreviewShippingResponse>(`${this.API}/client/orders/preview-shipping`, req);
  }

  // Tạo đơn hàng
  createOrder(req: CreateOrderRequest) {
    return this.http.post<any>(`${this.API}/client/orders`, req);
  }
}
